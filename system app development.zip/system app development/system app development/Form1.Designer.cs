﻿namespace system_app_development
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            labelFAH = new Label();
            pictureBox1 = new PictureBox();
            labelCEL = new Label();
            vScrollBar1TEMP = new VScrollBar();
            textBoxTempFah = new TextBox();
            textBoxTempCel = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // labelFAH
            // 
            labelFAH.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            labelFAH.Location = new Point(69, 68);
            labelFAH.Name = "labelFAH";
            labelFAH.Size = new Size(186, 52);
            labelFAH.TabIndex = 0;
            labelFAH.Text = "FAHRENHEIT";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(363, 68);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(315, 523);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // labelCEL
            // 
            labelCEL.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            labelCEL.Location = new Point(748, 68);
            labelCEL.Name = "labelCEL";
            labelCEL.Size = new Size(186, 52);
            labelCEL.TabIndex = 5;
            labelCEL.Text = "CELCIUS";
            // 
            // vScrollBar1TEMP
            // 
            vScrollBar1TEMP.Location = new Point(491, 100);
            vScrollBar1TEMP.Minimum = -80;
            vScrollBar1TEMP.Name = "vScrollBar1TEMP";
            vScrollBar1TEMP.Size = new Size(57, 466);
            vScrollBar1TEMP.TabIndex = 6;
            vScrollBar1TEMP.Scroll += vScrollBar1TEMP_Scroll;
            // 
            // textBoxTempFah
            // 
            textBoxTempFah.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxTempFah.Location = new Point(69, 188);
            textBoxTempFah.Name = "textBoxTempFah";
            textBoxTempFah.Size = new Size(192, 38);
            textBoxTempFah.TabIndex = 8;
            textBoxTempFah.Text = "32";
            textBoxTempFah.TextAlign = HorizontalAlignment.Center;
            textBoxTempFah.TextChanged += textBoxTempFah_TextChanged;
            // 
            // textBoxTempCel
            // 
            textBoxTempCel.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxTempCel.Location = new Point(742, 188);
            textBoxTempCel.Name = "textBoxTempCel";
            textBoxTempCel.Size = new Size(192, 38);
            textBoxTempCel.TabIndex = 9;
            textBoxTempCel.Text = "0";
            textBoxTempCel.TextAlign = HorizontalAlignment.Center;
            textBoxTempCel.TextChanged += textBoxTempCel_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1026, 706);
            Controls.Add(textBoxTempCel);
            Controls.Add(textBoxTempFah);
            Controls.Add(vScrollBar1TEMP);
            Controls.Add(labelCEL);
            Controls.Add(pictureBox1);
            Controls.Add(labelFAH);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelFAH;
        private PictureBox pictureBox1;
        private Label labelCEL;
        private VScrollBar vScrollBar1TEMP;
        private TextBox textBoxTempFah;
        private TextBox textBoxTempCel;
    }
}